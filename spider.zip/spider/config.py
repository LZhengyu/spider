# taobao

MONGO_URL='localhost'
MONGO_DB='taobao'
MONGO_TABLE='product'

#toutiao

# MONGO_URL='localhost'
# # MONGO_DB='toutiao'
# # MONGO_TABLE='toutiao'
# #
# # GROUP_START=1
# # GROUP_END=2